namespace KaraKuljaFund.MAUI.Views.Templates;

public partial class RuralGovMainViewTemplate : ContentView
{
	public RuralGovMainViewTemplate()
	{
		InitializeComponent();
	}
}