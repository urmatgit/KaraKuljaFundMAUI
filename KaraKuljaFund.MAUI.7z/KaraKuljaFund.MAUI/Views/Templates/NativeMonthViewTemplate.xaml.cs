namespace KaraKuljaFund.MAUI.Views.Templates;

public partial class NativeMonthViewTemplate : ContentView
{
	public NativeMonthViewTemplate()
	{
		InitializeComponent();
	}
}