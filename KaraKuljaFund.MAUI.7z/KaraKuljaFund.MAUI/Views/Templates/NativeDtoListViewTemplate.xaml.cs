namespace KaraKuljaFund.MAUI.Views.Templates;

public partial class NativeDtoListViewTemplate : ContentView
{
	public NativeDtoListViewTemplate()
	{
		InitializeComponent();
	}
}